#
# Example file for HelloWorld
#
print('Hello World')
